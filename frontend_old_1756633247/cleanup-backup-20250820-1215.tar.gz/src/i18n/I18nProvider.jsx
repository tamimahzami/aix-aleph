import React, { createContext, useContext, useMemo, useState } from "react";
import de from "./de.json";
import en from "./en.json";

const dict = { de, en };
const Ctx = createContext(null);

export function I18nProvider({ children, defaultLocale = "de" }) {
  const [locale, setLocale] = useState(defaultLocale);
  const t = (key) => {
    const parts = String(key).split(".");
    let cur = dict[locale] || {};
    for (const p of parts) cur = cur?.[p];
    return cur ?? key;
  };
  const value = useMemo(() => ({ t, locale, setLocale }), [t, locale]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useI18n() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useI18n must be used inside I18nProvider");
  return ctx;
}
