import React from "react";
export default function Admin() {
  return (
    <div className="card">
      <h2>Admin</h2>
      <p>Rollen, Nutzerverwaltung, System-Einstellungen.</p>
    </div>
  );
}
