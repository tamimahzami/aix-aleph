import React from "react";
export default function Maintenance() {
  return (
    <div className="card">
      <h2>Wartung</h2>
      <p>Störungen, Alarme, nächste Services.</p>
    </div>
  );
}
