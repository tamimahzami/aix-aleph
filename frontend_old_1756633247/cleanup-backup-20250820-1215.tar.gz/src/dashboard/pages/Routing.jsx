import React from "react";
export default function Routing() {
  return (
    <div className="card">
      <h2>Routenplanung</h2>
      <p>Start/Ziel, grünste/schnellste Route, Simulation.</p>
    </div>
  );
}
