import React from "react";
export default function Fleet() {
  return (
    <div className="card">
      <h2>Flottenmanagement</h2>
      <p>Fahrzeugliste, Status, Batterie, letzte Wartung.</p>
    </div>
  );
}
