import React from "react";
export default function Overview() {
  return (
    <div className="card">
      <h2>Übersicht</h2>
      <p>Hier kommen KPIs, Karte und Schnellstatistiken hin.</p>
    </div>
  );
}
