import React from "react";
export default function Monitoring() {
  return (
    <div className="card">
      <h2>Echtzeit-Monitoring</h2>
      <p>Liste/Map mit Live-Positionen, Status, Filter.</p>
    </div>
  );
}
