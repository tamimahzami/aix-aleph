import React from "react";
export default function Energy() {
  return (
    <div className="card">
      <h2>Energie</h2>
      <p>Verbrauch, Strommix, CO₂-Ersparnis.</p>
    </div>
  );
}
