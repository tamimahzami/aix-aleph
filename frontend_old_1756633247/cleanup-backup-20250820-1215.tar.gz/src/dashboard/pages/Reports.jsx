import React from "react";
export default function Reports() {
  return (
    <div className="card">
      <h2>Reports & Analytics</h2>
      <p>Zeitreihen, Vergleiche, Export nach CSV/PDF.</p>
    </div>
  );
}
