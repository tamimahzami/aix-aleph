// src/hooks/useCharging.js
export default function useCharging() {
  return { sessions: [], loading: false };
}
