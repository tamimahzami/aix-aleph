// src/hooks/useNotifications.js
export default function useNotifications() {
  return { notifications: [] };
}
