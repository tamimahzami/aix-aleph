import React, { useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { useTranslation } from "react-i18next";
import Logo from "./Logo";
import "./Header.css";

export default function Header() {
  const { i18n, t } = useTranslation?.() ?? { i18n: null, t: (k) => k };
  const [open, setOpen] = useState(false);

  const changeLanguage = (lng) => {
    if (i18n?.changeLanguage) i18n.changeLanguage(lng);
    setOpen(false);
  };

  const Item = ({ to, children }) => (
    <NavLink
      to={to}
      className={({ isActive }) => "nav-item" + (isActive ? " active" : "")}
      onClick={() => setOpen(false)}
    >
      {children}
    </NavLink>
  );

  return (
    <header className="site-header" role="banner">
      <div className="container header-row">
        <Link to="/" className="brand" aria-label="AIX Aleph – Home">
          <Logo />
        </Link>

        <nav className={"nav" + (open ? " open" : "")} aria-label="Hauptnavigation">
          <Item to="/business-areas">{t("nav.businessAreas") || "Geschäftsbereiche"}</Item>
          <Item to="/sustainability">{t("nav.sustainability") || "Sustainability"}</Item>
          <Item to="/citizenship">{t("nav.citizenship") || "Citizenship"}</Item>
          <Item to="/dashboard">{t("nav.dashboard") || "Dashboard"}</Item>

          <div className="lang-wrap" aria-label="Sprache wählen">
            <button
              className="lang-btn"
              onClick={() => changeLanguage("de")}
              aria-pressed={i18n?.language?.startsWith("de") ? "true" : "false"}
              title="Deutsch"
            >
              DE
            </button>
            <span className="lang-sep">/</span>
            <button
              className="lang-btn"
              onClick={() => changeLanguage("en")}
              aria-pressed={i18n?.language?.startsWith("en") ? "true" : "false"}
              title="English"
            >
              EN
            </button>
          </div>

          <Link to="/dashboard-demo" className="hdr-btn btn-outline">
            {t("nav.demo") || "Demo ansehen"}
          </Link>
          <Link to="/register" className="hdr-btn btn-primary">
            {t("nav.startFree") || "Kostenlos starten"}
          </Link>
        </nav>

        <button
          className={"hamburger" + (open ? " is-open" : "")}
          aria-label="Menü"
          aria-expanded={open ? "true" : "false"}
          onClick={() => setOpen(!open)}
        >
          <span /><span /><span />
        </button>
      </div>
    </header>
  );
}
