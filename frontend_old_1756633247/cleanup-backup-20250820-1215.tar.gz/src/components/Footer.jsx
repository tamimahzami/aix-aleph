import React from "react";
import { Link } from "react-router-dom";
import "./Footer.css";

export default function Footer() {
  return (
    <footer className="site-footer" role="contentinfo">
      <div className="container">
        {/* CTA */}
        <div className="footer-cta">
          <h3>Bereit für AI × Aleph?</h3>
          <p>Starte kostenlos oder erlebe die Demo live.</p>
          <div className="cta-actions">
            <Link to="/register" className="ftr-btn btn-primary">Kostenlos starten</Link>
            <Link to="/dashboard-demo" className="ftr-btn btn-outline">Demo ansehen</Link>
          </div>
        </div>

        {/* Grid */}
        <div className="footer-grid">
          <div>
            <h4>Unternehmen</h4>
            <ul>
              <li><Link to="/business-areas">Geschäftsbereiche</Link></li>
              <li><Link to="/about">Über uns</Link></li>
              <li><Link to="/careers">Jobs</Link></li>
              <li><Link to="/contact">Kontakt</Link></li>
            </ul>
          </div>
          <div>
            <h4>Produkt</h4>
            <ul>
              <li><Link to="/intelligent-charging">Intelligent Charging</Link></li>
              <li><Link to="/predictive-maintenance">Predictive Maintenance</Link></li>
              <li><Link to="/advanced-routing">Advanced Routing</Link></li>
              <li><Link to="/sustainability-reporting">Sustainability Reporting</Link></li>
            </ul>
          </div>
          <div>
            <h4>Rechtliches</h4>
            <ul>
              <li><Link to="/imprint">Impressum</Link></li>
              <li><Link to="/terms">AGB</Link></li>
              <li><Link to="/privacy">Datenschutz</Link></li>
              <li><Link to="/accessibility-statement">Erklärung zur Barrierefreiheit</Link></li>
            </ul>
          </div>
          <div>
            <h4>Kontakt</h4>
            <ul>
              <li>kontakt@aix-aleph.de</li>
              <li>+49 221 123456</li>
              <li>Aachener Straße 1, 50674 Köln</li>
              <li>
                <a href="https://www.linkedin.com" rel="noopener noreferrer" target="_blank">LinkedIn</a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="footer-bottom">
          <span>© {new Date().getFullYear()} AIX Aleph</span>
          <nav className="footer-mini">
            <Link to="/privacy">Datenschutz</Link>
            <Link to="/terms">AGB</Link>
            <Link to="/imprint">Impressum</Link>
          </nav>
        </div>
      </div>
    </footer>
  );
}
