// src/pages/Dashboard.jsx
import React, { useMemo, useState } from "react";
import {
  Box, Grid, Card, CardContent, Typography,
  Button, Divider, Chip, LinearProgress, IconButton
} from "@mui/material";
import {
  Dashboard as DashboardIcon,
  Refresh as RefreshIcon,
  PlayArrow as StartIcon,
  Stop as StopIcon,
  DirectionsCar as CarIcon,
  ElectricCar as EVIcon,
  DirectionsBus as BusIcon,
  BatteryChargingFull as ChargingIcon,
  Warning as WarningIcon,
  Notifications as NotificationsIcon,
  Map as MapIcon,
  TrendingUp as TrendIcon,
  Settings as SettingsIcon
} from "@mui/icons-material";

import useVehicles from "../hooks/useVehicles";
import useCharging from "../hooks/useCharging";
import useNotifications from "../hooks/useNotifications";
import VehicleMap from "../components/VehicleMap";
import { startCharging, stopCharging } from "../services/api";
import { checkServiceStatus, formatServiceStatus } from "../utils/maintenance";

const styles = {
  dashboard: {
    backgroundColor: '#f8fafc',
    minHeight: '100vh',
    py: 2,
    backgroundImage:
      'radial-gradient(circle at 10% 20%, rgba(37,99,235,0.05) 0%, transparent 20%), radial-gradient(circle at 90% 80%, rgba(139,92,246,0.05) 0%, transparent 20%)'
  },
  header: {
    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    mb: 4, gap: 2, backgroundColor: 'rgba(255,255,255,0.85)', backdropFilter: 'blur(10px)',
    padding: 16, borderRadius: 12, boxShadow: '0 4px 15px rgba(0,0,0,0.05)',
    border: '1px solid rgba(0,0,0,0.05)'
  },
  card: {
    backgroundColor: 'rgba(255,255,255,0.9)', backdropFilter: 'blur(10px)',
    borderRadius: 12, boxShadow: '0 8px 20px rgba(0,0,0,0.05)',
    border: '1px solid rgba(0,0,0,0.05)', transition: 'all .3s ease',
    '&:hover': { transform: 'translateY(-5px)', boxShadow: '0 15px 30px rgba(0,0,0,0.1)' }
  },
  kpiCard: { textAlign: 'center', padding: '20px 15px' },
  kpiValue: {
    fontSize: '2.4rem', fontWeight: 800,
    background: 'linear-gradient(90deg, #2563eb, #8b5cf6)',
    WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent', mb: 1
  },
  mapContainer: { height: 450, borderRadius: 8, overflow: 'hidden', position: 'relative' },
  vehicleItem: {
    display: 'flex', alignItems: 'center', gap: 16, padding: 16,
    borderRadius: 10, backgroundColor: 'rgba(37,99,235,0.03)',
    transition: 'all .3s ease', marginBottom: 12,
    cursor: 'pointer',
    '&:hover': { backgroundColor: 'rgba(37,99,235,0.08)' }
  },
  vehicleIcon: {
    width: 50, height: 50, borderRadius: 10,
    background: 'linear-gradient(135deg, #2563eb, #06b6d4)',
    display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff'
  },
  primaryButton: {
    background: 'linear-gradient(90deg, #2563eb, #8b5cf6)', color: 'white', fontWeight: 600,
    boxShadow: '0 4px 15px rgba(37,99,235,.3)',
    '&:hover': { transform: 'translateY(-3px)', boxShadow: '0 6px 20px rgba(37,99,235,.4)' }
  },
  secondaryButton: {
    background: 'transparent', color: '#2563eb', border: '2px solid #2563eb', fontWeight: 600,
    '&:hover': { transform: 'translateY(-3px)', boxShadow: '0 6px 20px rgba(37,99,235,.15)' }
  },
  statusDot: { width: 10, height: 10, borderRadius: '50%', display: 'inline-block', marginRight: 6 },
  activeStatus: { backgroundColor: '#10b981' },
  warningStatus: { backgroundColor: '#f59e0b' },
  criticalStatus: { backgroundColor: '#ef4444' },
  notificationItem: {
    padding: 16, borderRadius: 10, display: 'flex', gap: 12, alignItems: 'flex-start',
    backgroundColor: 'rgba(239,68,68,0.05)', borderLeft: '3px solid #ef4444', marginBottom: 12
  }
};

const Demo = {
  vehicles: [
    { id: "EV-1001", name: "E-Bus #12", status: "ONLINE", battery: 82, latitude: 52.52, longitude: 13.405, mileage: 38420, lastServiceMileage: 30000, serviceInterval: 15000, chargingSessions: [], type: "bus" },
    { id: "EV-1002", name: "ID.4 Business", status: "CHARGING", battery: 37, latitude: 48.137, longitude: 11.575, mileage: 21500, lastServiceMileage: 15000, serviceInterval: 15000, chargingSessions: [{ id: "sess-1", startTime: Date.now() - 3600e3 }], type: "car" },
    { id: "EV-1003", name: "e-Transporter", status: "MAINTENANCE", battery: 95, latitude: 50.1109, longitude: 8.6821, mileage: 18200, lastServiceMileage: 10000, serviceInterval: 20000, chargingSessions: [], type: "truck" },
    { id: "EV-1004", name: "e-Scooter #45", status: "ONLINE", battery: 64, latitude: 53.5511, longitude: 9.9937, mileage: 4200, lastServiceMileage: 3000, serviceInterval: 5000, chargingSessions: [], type: "scooter" }
  ],
  sessions: [ { id: "sess-1", vehicleId: "EV-1002", powerKW: 42, startedAt: Date.now() - 3600e3 } ],
  notifications: [
    { id: 1, type: "warning",  text: "Niedriger Batteriestand: E-Bus #15 hat nur noch 18% Akku", time: "Vor 15 Min." },
    { id: 2, type: "info",     text: "Stau auf Linie 8 - Alternative Route aktiviert",           time: "Vor 28 Min." },
    { id: 3, type: "critical", text: "Reifendruck bei EV-1002 kritisch niedrig",                 time: "Vor 2 Std." }
  ],
};

function usePresentationFallback(data, demo) {
  const hashOrSearch =
    typeof window !== "undefined" ? window.location.search + window.location.hash : "";
  const forceDemo = /\bdemo\b/i.test(hashOrSearch);
  const isEmpty =
    !data ||
    (Array.isArray(data) && data.length === 0) ||
    (typeof data === "object" && Object.keys(data || {}).length === 0);

  return forceDemo || isEmpty ? demo : data;
}

export default function Dashboard() {
  const {
    vehicles, loading: vLoading, error: vError, reload: reloadVehicles,
  } = useVehicles?.() || { vehicles: [], loading: false, error: null, reload: async () => {} };

  const { sessions, loading: sLoading } = useCharging?.() || { sessions: [], loading: false };
  const { notifications } = useNotifications?.() || { notifications: [] };

  const safeVehicles = usePresentationFallback(vehicles, Demo.vehicles);
  const safeSessions  = usePresentationFallback(sessions, Demo.sessions);
  const safeNotifs    = usePresentationFallback(notifications, Demo.notifications);

  const [selectedVehicleId, setSelectedVehicleId] = useState("");
  const selectedVehicle =
    (safeVehicles.find(v => String(v.id) === String(selectedVehicleId)) || safeVehicles[0]) || null;

  const kpi = useMemo(() => {
    const total = safeVehicles.length;
    const online = safeVehicles.filter(v => {
      const s = (v.status || "").toUpperCase();
      return s === "ONLINE" || s === "ACTIVE";
    }).length;
    const charging = safeVehicles.filter(
      v => Array.isArray(v.chargingSessions) && v.chargingSessions.some(cs => !cs.endTime)
    ).length;
    const avgBattery = total
      ? Math.round(safeVehicles.reduce((s, v) => s + (v.battery ?? 0), 0) / total)
      : 0;
    return { total, online, charging, avgBattery };
  }, [safeVehicles]);

  async function onStartCharging() {
    if (!selectedVehicle) return;
    try { await startCharging?.(selectedVehicle.id, "DEMO-PLUG"); await reloadVehicles(); } catch {}
  }
  async function onStopCharging() {
    try { const sess = safeSessions[0]?.id || "DEMO-SESSION"; await stopCharging?.(sess); await reloadVehicles(); } catch {}
  }

  const isLoading = vLoading || sLoading;

  const vehiclesForMap = useMemo(
    () => safeVehicles.map(v => ({ ...v, lat: v.lat ?? v.latitude ?? null, lng: v.lng ?? v.longitude ?? null })),
    [safeVehicles]
  );

  const getVehicleIcon = (type) => {
    switch (type) { case "bus": return <BusIcon fontSize="large" />;
      case "truck": return <EVIcon fontSize="large" />;
      case "scooter": return <CarIcon fontSize="large" />;
      default: return <CarIcon fontSize="large" />; }
  };

  return (
    <Box sx={styles.dashboard}>
      <Box sx={styles.header}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <DashboardIcon fontSize="large" color="primary" />
          <Typography variant="h4" fontWeight={700}>
            <Box component="span" sx={{
              background: 'linear-gradient(90deg, #2563eb, #8b5cf6)',
              WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent'
            }}>
              Flotten Dashboard
            </Box>
          </Typography>
        </Box>

        <Box sx={{ display: "flex", gap: 8, alignItems: "center" }}>
          {safeVehicles.length > 0 && (
            <select
              value={selectedVehicleId}
              onChange={(e) => setSelectedVehicleId(e.target.value)}
              style={{ padding: "10px 15px", borderRadius: 8, border: "1px solid #ddd", background: "#fff", fontSize: '1rem' }}
              aria-label="Fahrzeug wählen"
            >
              <option value="">Fahrzeug wählen...</option>
              {safeVehicles.map(v => <option key={v.id} value={v.id}>{v.name ?? v.id}</option>)}
            </select>
          )}

          <Button variant="outlined" onClick={reloadVehicles} startIcon={<RefreshIcon />} sx={styles.secondaryButton}>
            Aktualisieren
          </Button>
          <Button variant="contained" onClick={onStartCharging} startIcon={<StartIcon />} sx={styles.primaryButton}>
            Laden starten
          </Button>
          <Button variant="outlined" color="warning" onClick={onStopCharging} startIcon={<StopIcon />}
                  sx={{ ...styles.secondaryButton, borderColor: '#f59e0b', color: '#f59e0b' }}>
            Laden stoppen
          </Button>
        </Box>
      </Box>

      {isLoading && <LinearProgress sx={{ mb: 2 }} />}

      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ ...styles.card, ...styles.kpiCard }}>
            <Typography variant="overline" color="text.secondary">Fahrzeuge gesamt</Typography>
            <Typography sx={styles.kpiValue}>{kpi.total}</Typography>
            <Divider sx={{ my: 1.5 }} />
            <Typography variant="body2" color="text.secondary">Bestand deiner Flotte</Typography>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ ...styles.card, ...styles.kpiCard }}>
            <Typography variant="overline" color="text.secondary">Online & Aktiv</Typography>
            <Typography sx={styles.kpiValue}>{kpi.online}</Typography>
            <Divider sx={{ my: 1.5 }} />
            <Typography variant="body2" color="text.secondary">
              <Box component="span" sx={{ ...styles.statusDot, ...styles.activeStatus }} />Verfügbar
            </Typography>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ ...styles.card, ...styles.kpiCard }}>
            <Typography variant="overline" color="text.secondary">Ladevorgänge</Typography>
            <Typography sx={styles.kpiValue}>{kpi.charging}</Typography>
            <Divider sx={{ my: 1.5 }} />
            <Typography variant="body2" color="text.secondary">
              <ChargingIcon fontSize="small" sx={{ verticalAlign: 'middle', mr: 1 }} />Aktuell laufend
            </Typography>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ ...styles.card, ...styles.kpiCard }}>
            <Typography variant="overline" color="text.secondary">Ø Batteriestand</Typography>
            <Typography sx={styles.kpiValue}>{kpi.avgBattery}%</Typography>
            <Divider sx={{ my: 1.5 }} />
            <LinearProgress variant="determinate" value={kpi.avgBattery}
                            sx={{ height: 8, borderRadius: 1, background: 'rgba(37,99,235,0.1)' }} />
          </Card>
        </Grid>
      </Grid>

      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          <Card sx={styles.card}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2, gap: 1 }}>
                <MapIcon color="primary" />
                <Typography variant="h6" fontWeight={600}>Echtzeit-Fahrzeugtracking</Typography>
                <Chip label={`${safeVehicles.length} Fahrzeuge`} size="small" sx={{ ml: 'auto' }} />
              </Box>
              <Box sx={styles.mapContainer}>
                <VehicleMap vehicles={vehiclesForMap} />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={4}>
          <Card sx={{ ...styles.card, height: '100%' }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2, gap: 1 }}>
                <CarIcon color="primary" />
                <Typography variant="h6" fontWeight={600}>Fahrzeugstatus</Typography>
                <IconButton sx={{ ml: 'auto' }}><SettingsIcon /></IconButton>
              </Box>

              {safeVehicles.map(v => {
                const code = checkServiceStatus(v);
                const label = formatServiceStatus(code);
                const dotStyle =
                  v.status === 'ONLINE' ? styles.activeStatus :
                  v.status === 'MAINTENANCE' ? styles.warningStatus : styles.criticalStatus;

                return (
                  <Box key={v.id} sx={styles.vehicleItem} onClick={() => setSelectedVehicleId(v.id)}>
                    <Box sx={styles.vehicleIcon}>{getVehicleIcon(v.type)}</Box>
                    <Box sx={{ flex: 1 }}>
                      <Typography fontWeight={600}>{v.name}</Typography>
                      <Typography variant="body2" color="text.secondary">
                        <Box component="span" sx={{ ...styles.statusDot, ...dotStyle }} />
                        {v.status} • Akku: {v.battery ?? "–"}%
                      </Typography>
                    </Box>
                    <Chip label={label} color={code === "OK" ? "success" : "warning"} variant="outlined" size="small" />
                  </Box>
                );
              })}
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={6}>
          <Card sx={styles.card}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2, gap: 1 }}>
                <NotificationsIcon color="primary" />
                <Typography variant="h6" fontWeight={600}>Systemwarnungen</Typography>
                <Chip label={`${safeNotifs.length} neue`} color="error" size="small" sx={{ ml: 'auto' }} />
              </Box>

              {safeNotifs.length === 0 ? (
                <Typography variant="body2" color="text.secondary" textAlign="center" py={4}>
                  Keine neuen Benachrichtigungen
                </Typography>
              ) : (
                <Box>
                  {safeNotifs.map(n => (
                    <Box key={n.id} sx={styles.notificationItem}>
                      <Box sx={{ color: n.type === 'critical' ? '#ef4444' : n.type === 'warning' ? '#f59e0b' : '#2563eb' }}>
                        <WarningIcon fontSize="medium" />
                      </Box>
                      <Box sx={{ flex: 1 }}>
                        <Typography fontWeight={600}>{n.text}</Typography>
                        <Typography variant="body2" color="text.secondary">{n.time}</Typography>
                      </Box>
                    </Box>
                  ))}
                </Box>
              )}
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={6}>
          <Card sx={styles.card}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2, gap: 1 }}>
                <TrendIcon color="primary" />
                <Typography variant="h6" fontWeight={600}>Energieverbrauch</Typography>
              </Box>

              <Box sx={{ display: 'flex', justifyContent: 'space-around', textAlign: 'center', mt: 3 }}>
                <Box>
                  <Typography variant="h4" sx={{ color: '#2563eb' }}>2.4</Typography>
                  <Typography variant="body2" color="text.secondary">kWh/km Ø</Typography>
                </Box>
                <Box>
                  <Typography variant="h4" sx={{ color: '#10b981' }}>-12%</Typography>
                  <Typography variant="body2" color="text.secondary">vs. Vorwoche</Typography>
                </Box>
                <Box>
                  <Typography variant="h4" sx={{ color: '#8b5cf6' }}>42 kW</Typography>
                  <Typography variant="body2" color="text.secondary">Ladeleistung</Typography>
                </Box>
              </Box>

              <Box sx={{ mt: 3, textAlign: 'center' }}>
                <Button variant="contained" sx={styles.primaryButton} startIcon={<ChargingIcon />}>
                  Ladestationen anzeigen
                </Button>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {vError && (
        <Box sx={{ mt: 2, textAlign: 'center' }}>
          <Chip color="error" label={`Backend-Fehler: ${vError.message || String(vError)}`} icon={<WarningIcon />} sx={{ py: 2, px: 3 }} />
        </Box>
      )}
    </Box>
  );
}
