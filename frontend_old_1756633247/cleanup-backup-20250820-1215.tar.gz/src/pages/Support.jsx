export default function Support() {
  return (
    <div className="card">
      <h1>Support</h1>
      <p>FAQ, Kontakt, Störungsmeldung – Platzhalter.</p>
    </div>
  );
}
