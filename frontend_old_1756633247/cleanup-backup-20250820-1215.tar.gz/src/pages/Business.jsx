import React from 'react';
import '../styles/page.css';

export default function Business() {
  return (
    <div className="page-container">
      <section className="page-hero">
        <h1>Mobilitätslösungen für Unternehmen</h1>
        <p>
          AIX ALEPH Mobility unterstützt Unternehmen bei der nachhaltigen Transformation ihrer
          Flotten – von PKWs bis hin zu LKWs und Sonderfahrzeugen.
        </p>
      </section>

      <section className="page-content card">
        <h2>Ihre Vorteile</h2>
        <ul>
          <li>Ganzheitliches Flottenmanagement in einer Plattform</li>
          <li>Vermeidung von Ausfällen durch proaktives Monitoring</li>
          <li>Transparente Kosten- und Emissionskontrolle</li>
        </ul>
      </section>
    </div>
  );
}
