export default function AboutPage() {
  return (
    <div style={{ padding: 24, fontFamily: "system-ui" }}>
      <h1>About (real)</h1>
      <p>Über diese App…</p>
    </div>
  );
}
