import React from "react";
import "./DashboardDemo.css";

export default function DashboardDemo() {
  return (
    <main className="demo-wrap">
      <header className="demo-header">
        <h1>Dashboard Demo</h1>
        <p className="muted">
          Interaktive Vorschau: KPIs, Charts (placeholder) & Live-Feeling – ohne Backend.
        </p>
      </header>

      {/* KPI Cards */}
      <section className="demo-grid">
        <div className="kpi-card">
          <div className="kpi-label">Fahrzeuge gesamt</div>
          <div className="kpi-value">128</div>
          <div className="kpi-sub">+6 seit letzter Woche</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-label">Online & aktiv</div>
          <div className="kpi-value">94</div>
          <div className="kpi-sub ok">74% verfügbar</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-label">Ladevorgänge</div>
          <div className="kpi-value">18</div>
          <div className="kpi-sub warn">Spitze erwartet 17:00</div>
        </div>
        <div className="kpi-card">
          <div className="kpi-label">Ø Batteriestand</div>
          <div className="kpi-value">67%</div>
          <div className="kpi-bar">
            <span style={{ width: "67%" }} />
          </div>
        </div>
      </section>

      {/* Widgets */}
      <section className="widgets-grid">
        <div className="widget">
          <div className="widget-head">
            <h3>Energieverbrauch (heute)</h3>
            <span className="chip">Live</span>
          </div>
          <div className="widget-body">
            <div className="bars">
              {["00", "03", "06", "09", "12", "15", "18", "21"].map((h, i) => {
                const val = [120, 80, 150, 220, 280, 250, 320, 180][i];
                const pct = Math.round((val / 320) * 100);
                return (
                  <div key={h} className="bar">
                    <div className="bar-fill" style={{ height: `${pct}%` }} />
                    <div className="bar-label">{h}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="widget">
          <div className="widget-head">
            <h3>Top 5 Ladepunkte</h3>
            <span className="chip blue">Today</span>
          </div>
          <div className="widget-body list">
            {[
              ["Station A", 35],
              ["Station B", 25],
              ["Station C", 20],
              ["Station D", 15],
              ["Station E", 5],
            ].map(([name, val]) => (
              <div key={name} className="list-row">
                <span>{name}</span>
                <span className="pill">{val}%</span>
              </div>
            ))}
          </div>
        </div>

        <div className="widget">
          <div className="widget-head">
            <h3>Hinweise & Anomalien</h3>
            <span className="chip orange">AI</span>
          </div>
          <div className="widget-body notices">
            <div className="notice warn">
              <strong>Hinweis:</strong> Linie B-23 seit 09:45 ~8% unter Erwartung.
              Mögliche Korrelation: Materialcharge #4711.
            </div>
            <div className="notice info">
              <strong>Prognose:</strong> Tagesziel Auslastung 87% (Ziel 90%).
            </div>
            <div className="notice ok">
              <strong>Stabil:</strong> Ladecluster Nord im Soll (+2% Puffer).
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
