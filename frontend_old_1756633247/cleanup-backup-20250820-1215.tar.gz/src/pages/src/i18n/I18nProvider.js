import React, { useMemo } from "react";
import i18n from "i18next";
import { initReactI18next, I18nextProvider, useTranslation } from "react-i18next";

const resources = {
  de: {
    translation: {
      "nav.home": "Start",
      "nav.about": "Über uns",
      "nav.status": "Status",
      "nav.login": "Login",
      "nav.register": "Registrieren",
      "nav.dashboard": "Dashboard",
      "dashboard.title": "Operations Dashboard",
      "dashboard.timeRange": "Zeitraum",
      "dashboard.today": "Heute",
      "dashboard.thisWeek": "Diese Woche",
      "dashboard.thisMonth": "Dieser Monat",
      "dashboard.overview": "Übersicht",
      "dashboard.vehicles": "Fahrzeuge",
      "dashboard.charging": "Laden",
      "dashboard.routes": "Routen",
      "dashboard.analytics": "Analytics",
      "dashboard.underDevelopment": "Bereich in Arbeit",
      "dashboard.featureComingSoon": "Diese Funktion wird bald verfügbar sein.",
      "dashboard.vehicleStatus": "Fahrzeugstatus",
      "dashboard.currentUtilization": "Aktuelle Auslastung",
      "dashboard.predictedUtilization": "Prognose (EoD)",
      "dashboard.utilizationPrediction": "Modellierte Schichtauslastung basierend auf Verlauf & Routen.",
      "dashboard.utilizationWarning": "Ziel wird voraussichtlich verfehlt.",
      "dashboard.actual": "Ist",
      "dashboard.predicted": "Prognose",
      "dashboard.chargingManagement": "Lademanagement",
      "dashboard.activeCharging": "Aktive Ladevorgänge",
      "dashboard.availableStations": "Verfügbare Stationen",
      "dashboard.chargingDistribution": "Verteilung nach Station",
      "dashboard.chargingOptimization": "Tipp: Lastspitzen vermeiden – Nachtfenster nutzen.",
      "dashboard.routeOptimization": "Routenoptimierung",
      "dashboard.routeOptimizationDesc": "Clustering & Kürzung von Leerfahrten.",
      "dashboard.efficiency": "Effizienz",
      "dashboard.optimizeRoutes": "KI-Optimierung anwenden (K-Means Demo)",
      "dashboard.energyConsumption": "Energieverbrauch",
      "dashboard.dailyConsumption": "Heutiger Verbrauch",
      "dashboard.consumptionKwh": "Verbrauch (kWh)",
      "dashboard.consumptionPrediction": "Prognose: 5–8% Einsparung bei optimiertem Laden.",
      "dashboard.anomalyDetection": "Anomalie-Erkennung",
      "dashboard.anomalyDetected": "Anomalien erkannt: Bitte prüfen.",
      "dashboard.anomalyExplanation": "Leistungsabfall gegen 12:00 – mögliche Materialcharge-Korrelation."
    }
  }
};

if (!i18n.isInitialized) {
  i18n.use(initReactI18next).init({
    resources,
    lng: "de",
    fallbackLng: "de",
    interpolation: { escapeValue: false }
  });
}

export function I18nProvider({ children }) {
  return <I18nextProvider i18n={i18n}>{children}</I18nextProvider>;
}

export const useI18n = () => useTranslation();
