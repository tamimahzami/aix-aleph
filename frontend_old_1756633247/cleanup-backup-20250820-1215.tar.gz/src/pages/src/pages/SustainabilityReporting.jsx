import React from "react";

export default function SustainabilityReporting() {
  return (
    <main style={{ padding: 24 }}>
      <h1>Sustainability Reporting</h1>
      <p>Platzhalter – Inhalte folgen.</p>
    </main>
  );
}
