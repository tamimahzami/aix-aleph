import React from "react";
export default function AccessibilityPage(){return (<div className="page"><h1>Barrierefreiheit</h1><p className="kicker">Inklusive Technologie</p></div>);}
