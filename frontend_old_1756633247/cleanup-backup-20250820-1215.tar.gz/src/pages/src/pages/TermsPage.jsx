import React from "react";
export default function TermsPage(){return (<div className="page"><h1>AGB</h1><p className="kicker">Allgemeine Geschäftsbedingungen</p></div>);}
