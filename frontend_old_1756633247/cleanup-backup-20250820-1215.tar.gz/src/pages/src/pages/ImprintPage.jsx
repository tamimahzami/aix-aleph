import React from "react";
export default function ImprintPage(){return (<div className="page"><h1>Impressum</h1><p className="kicker">Rechtliche Angaben</p></div>);}
