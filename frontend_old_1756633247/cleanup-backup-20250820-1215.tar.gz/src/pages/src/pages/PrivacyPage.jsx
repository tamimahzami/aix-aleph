import React from "react";
export default function PrivacyPage(){return (<div className="page"><h1>Datenschutz</h1><p className="kicker">DSGVO</p></div>);}
