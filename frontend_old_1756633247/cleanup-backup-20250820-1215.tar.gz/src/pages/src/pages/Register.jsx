import React from "react";
export default function Register(){return (<div className="page"><h1>Registrieren</h1><p className="kicker">Konto erstellen</p></div>);}
