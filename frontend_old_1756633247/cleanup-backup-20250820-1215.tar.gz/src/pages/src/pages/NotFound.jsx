import React from "react";
export default function NotFound(){return (<div className="page"><h1>Seite nicht gefunden</h1><p className="kicker">404</p></div>);}
