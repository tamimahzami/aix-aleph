import React from "react";
export default function SupplyChainPage(){return (<div className="page"><h1>LkSG</h1><p className="kicker">Lieferkettensorgfaltspflicht</p></div>);}
