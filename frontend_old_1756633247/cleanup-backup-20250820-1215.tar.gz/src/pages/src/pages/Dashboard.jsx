cat > src/pages/Dashboard.jsx <<'EOF'
import React, { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Grid, Card, CardContent, Typography, Box, Alert, LinearProgress, Tabs, Tab } from "@mui/material";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

const vehicleData=[{name:"Jan",current:65,predicted:70},{name:"Feb",current:72,predicted:75},{name:"Mar",current:78,predicted:80},{name:"Apr",current:75,predicted:78},{name:"Mai",current:80,predicted:82},{name:"Jun",current:82,predicted:85}];
const chargingData=[{name:"Station A",value:35},{name:"Station B",value:25},{name:"Station C",value:20},{name:"Station D",value:15},{name:"Station E",value:5}];
const COLORS=["#0088FE","#00C49F","#FFBB28","#FF8042","#8884D8"];
const energyConsumptionData=[{hour:"00:00",consumption:120},{hour:"03:00",consumption:80},{hour:"06:00",consumption:150},{hour:"09:00",consumption:220},{hour:"12:00",consumption:280},{hour:"15:00",consumption:250},{hour:"18:00",consumption:320},{hour:"21:00",consumption:180}];

const KPI = ({label,value,ok=true}) => (
  <Card><CardContent><Typography variant="overline" color="text.secondary">{label}</Typography>
  <Typography variant="h4" sx={{mt:1, mb:1}}>{value}</Typography>
  <LinearProgress variant="determinate" value={Math.min(100, Number(value)||0)} color={ok?"success":"warning"} />
  </CardContent></Card>
);

export default function Dashboard(){
  const { t } = useTranslation();
  const [tab,setTab]=useState(0);
  return (
    <div className="page">
      <Box sx={{display:"flex",justifyContent:"space-between",alignItems:"center",mb:2}}>
        <Typography variant="h5">{t('dashboard.title')}</Typography>
        <Tabs value={tab} onChange={(_,v)=>setTab(v)}>
          <Tab label={t('dashboard.overview')}/>
          <Tab label={t('dashboard.vehicles')}/>
          <Tab label={t('dashboard.charging')}/>
          <Tab label={t('dashboard.routes')}/>
          <Tab label={t('dashboard.analytics')}/>
        </Tabs>
      </Box>

      {tab===0 && (
        <Grid container spacing={2}>
          <Grid item xs={12} md={3}><KPI label="Auslastung (%)" value={82}/></Grid>
          <Grid item xs={12} md={3}><KPI label="Ø Akku (%)" value={64}/></Grid>
          <Grid item xs={12} md={3}><KPI label="Ladevorgänge" value={12}/></Grid>
          <Grid item xs={12} md={3}><KPI label="Pünktlichkeit (%)" value={98}/></Grid>

          <Grid item xs={12} md={6}>
            <Card><CardContent>
              <Typography variant="h6" sx={{mb:1}}>Auslastung (Ist vs Prognose)</Typography>
              <ResponsiveContainer width="100%" height={240}>
                <LineChart data={vehicleData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name"/><YAxis/><Tooltip/><Legend/>
                  <Line type="monotone" dataKey="current" stroke="#2563eb" name="Ist"/>
                  <Line type="monotone" dataKey="predicted" stroke="#10b981" name="Prognose" strokeDasharray="5 5"/>
                </LineChart>
              </ResponsiveContainer>
            </CardContent></Card>
          </Grid>

          <Grid item xs={12} md={6}>
            <Card><CardContent>
              <Typography variant="h6" sx={{mb:1}}>Energieverbrauch (heute)</Typography>
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={energyConsumptionData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="hour"/><YAxis/><Tooltip/><Legend/>
                  <Bar dataKey="consumption" fill="#8b5cf6" name="kWh" />
                </BarChart>
              </ResponsiveContainer>
              <Alert severity="info" sx={{mt:1}}>Prognose: 5–8% Einsparung bei optimiertem Laden.</Alert>
            </CardContent></Card>
          </Grid>

          <Grid item xs={12} md={6}>
            <Card><CardContent>
              <Typography variant="h6" sx={{mb:1}}>Ladeverteilung</Typography>
              <ResponsiveContainer width="100%" height={240}>
                <PieChart>
                  <Pie data={chargingData} dataKey="value" cx="50%" cy="50%" outerRadius={90} label>
                    {chargingData.map((e,i)=><Cell key={i} fill={COLORS[i%COLORS.length]}/>)}
                  </Pie>
                  <Tooltip/>
                </PieChart>
              </ResponsiveContainer>
            </CardContent></Card>
          </Grid>

          <Grid item xs={12} md={6}>
            <Card><CardContent>
              <Typography variant="h6" sx={{mb:1}}>Hinweise</Typography>
              <Alert severity="warning" sx={{mb:1}}>Anomalie 12:00 – mögliche Materialcharge-Korrelation.</Alert>
              <Alert severity="success">Routenoptimierung aktiv: Leerfahrten -12%.</Alert>
            </CardContent></Card>
          </Grid>
        </Grid>
      )}

      {tab!==0 && (
        <Box sx={{p:3, textAlign:"center"}}>
          <Typography variant="h6">{t('dashboard.underDevelopment')}</Typography>
          <Typography color="text.secondary">{t('dashboard.featureComingSoon')}</Typography>
        </Box>
      )}
    </div>
  );
}
EOF
