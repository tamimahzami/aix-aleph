import React from "react";

export default function PredictiveMaintenance() {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>Predictive Maintenance</h1>
      <p className="kicker">Vorausschauende Wartung</p>
      <p>
        Diese Seite wird Funktionen zur vorausschauenden Wartung beschreiben.
        Später kommen hier Einblicke in Sensordaten, KI-Analysen und Warnsysteme.
      </p>
    </div>
  );
}
