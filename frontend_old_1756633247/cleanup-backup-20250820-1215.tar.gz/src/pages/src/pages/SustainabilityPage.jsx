import React from "react";
export default function SustainabilityPage(){return (<div className="page"><h1>Corporate Sustainability</h1><p className="kicker">Nachhaltigkeit im Fokus</p></div>);}
