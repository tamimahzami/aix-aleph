import React from "react";
export default function Status(){return (<div className="page"><h1>Systemstatus</h1><p className="kicker">Uptime, Releases, Incidents</p></div>);}
