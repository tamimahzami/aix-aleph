import React, { useMemo, useState } from "react";
import {
  Box, Grid, Card, CardContent, Typography, Button, Divider,
  Chip, LinearProgress, Alert
} from "@mui/material";
import {
  ResponsiveContainer, LineChart, Line, XAxis, YAxis,
  CartesianGrid, Tooltip, Legend, BarChart, Bar
} from "recharts";

function KPICard({ label, value, subtitle, progress }) {
  return (
    <Card sx={{ borderRadius: 3, boxShadow: "0 8px 24px rgba(0,0,0,0.06)" }}>
      <CardContent>
        <Typography variant="overline" color="text.secondary">{label}</Typography>
        <Typography
          variant="h4"
          sx={{
            fontWeight: 800,
            mt: .5,
            background: "linear-gradient(90deg,#2563eb,#8b5cf6)",
            WebkitBackgroundClip: "text",
            color: "transparent"
          }}
        >
          {value}
        </Typography>
        <Divider sx={{ my: 1.5 }} />
        {typeof progress === "number" ? (
          <LinearProgress
            variant="determinate"
            value={progress}
            sx={{ height: 8, borderRadius: 1, background: "rgba(37,99,235,.1)" }}
          />
        ) : (
          <Typography variant="body2" color="text.secondary">{subtitle}</Typography>
        )}
      </CardContent>
    </Card>
  );
}

function makeTrend() {
  // Demo: generiert eine Wochenreihe Mo–So
  const labels = ["Mo","Di","Mi","Do","Fr","Sa","So"];
  const base = 70 + Math.random() * 10;
  return labels.map((d, i) => ({
    day: d,
    utilization: Math.round(base + Math.sin(i/2) * 12 + (Math.random()*4 - 2))
  }));
}

function makeEnergy() {
  return [
    { segment: "E-Busse", kwh: Math.round(100 + Math.random()*40) },
    { segment: "PKW",     kwh: Math.round(70 + Math.random()*35) },
    { segment: "Nutzfzg", kwh: Math.round(80 + Math.random()*30) },
    { segment: "Micro",   kwh: Math.round(25 + Math.random()*15) },
  ];
}

export default function DashboardDemo() {
  const [seed, setSeed] = useState(Date.now());
  const trend = useMemo(() => makeTrend(), [seed]);
  const energy = useMemo(() => makeEnergy(), [seed]);

  // KPIs aus den Demo-Daten "abgeleitet"
  const active = 42 + (seed % 3); // 42–44
  const utilization = Math.min(98, Math.max(55, Math.round(
    trend.reduce((s,d)=>s+d.utilization,0)/trend.length
  )));
  const avgBattery = 62 + ((seed/7)%25|0); // ~62–86
  const charging = 5 + (seed % 6); // 5–10

  const lastUpdated = new Date(seed).toLocaleTimeString();

  return (
    <Box sx={{ p: 3, pb: 6 }}>
      {/* Header */}
      <Box sx={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        mb: 3, p: 2, borderRadius: 3, bgcolor: "rgba(255,255,255,0.9)",
        boxShadow: "0 6px 18px rgba(0,0,0,0.06)", border: "1px solid rgba(0,0,0,0.05)"
      }}>
        <Box>
          <Typography variant="h5" sx={{ fontWeight: 800 }}>
            Flotten-Dashboard (Demo)
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Zuletzt aktualisiert: {lastUpdated}
          </Typography>
        </Box>
        <Box sx={{ display: "flex", gap: 1 }}>
          <Button
            variant="outlined"
            onClick={() => setSeed(Date.now())}
            sx={{ borderRadius: 2, borderColor: "#2563eb", color: "#2563eb", fontWeight: 600 }}
          >
            Aktualisieren
          </Button>
          <Button
            variant="contained"
            href="/dashboard"
            sx={{
              borderRadius: 2, fontWeight: 700,
              background: "linear-gradient(90deg,#2563eb,#8b5cf6)",
              boxShadow: "0 8px 20px rgba(37,99,235,.35)"
            }}
          >
            Volles Dashboard öffnen
          </Button>
        </Box>
      </Box>

      {/* KPI Row */}
      <Grid container spacing={3} sx={{ mb: 1 }}>
        <Grid item xs={12} sm={6} md={3}>
          <KPICard label="Aktive Fahrzeuge" value={active} subtitle="live" />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <KPICard label="Auslastung Ø" value={`${utilization}%`} progress={utilization} />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <KPICard label="Ø Batteriestand" value={`${avgBattery}%`} progress={avgBattery} />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <KPICard label="Ladevorgänge" value={charging} subtitle="aktuell laufend" />
        </Grid>
      </Grid>

      {/* Charts */}
      <Grid container spacing={3}>
        <Grid item xs={12} md={7}>
          <Card sx={{ borderRadius: 3, height: 360, boxShadow: "0 8px 24px rgba(0,0,0,.06)" }}>
            <CardContent sx={{ height: "100%" }}>
              <Box sx={{ display: "flex", alignItems: "center", mb: 1 }}>
                <Typography variant="h6" sx={{ fontWeight: 700 }}>
                  Auslastung – letzte 7 Tage
                </Typography>
                <Chip size="small" label="Trend" sx={{ ml: 1 }} />
              </Box>
              <Box sx={{ height: 280 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={trend}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="utilization" name="Auslastung (%)" stroke="#2563eb" strokeWidth={2} dot={false}/>
                  </LineChart>
                </ResponsiveContainer>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={5}>
          <Card sx={{ borderRadius: 3, height: 360, boxShadow: "0 8px 24px rgba(0,0,0,.06)" }}>
            <CardContent sx={{ height: "100%" }}>
              <Box sx={{ display: "flex", alignItems: "center", mb: 1 }}>
                <Typography variant="h6" sx={{ fontWeight: 700 }}>
                  Energie nach Segment (kWh)
                </Typography>
                <Chip size="small" label="heute" sx={{ ml: 1 }} />
              </Box>
              <Box sx={{ height: 280 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={energy}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="segment" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="kwh" name="kWh/Tag" fill="#8b5cf6" radius={[6,6,0,0]} />
                  </BarChart>
                </ResponsiveContainer>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* KI Insight */}
        <Grid item xs={12}>
          <Alert severity={utilization < 90 ? "warning" : "success"} sx={{ borderRadius: 2 }}>
            <strong>KI-Insight:</strong>{" "}
            {utilization < 90
              ? "Prognose verfehlt das 90%-Ziel leicht. Empfehlung: Ladefenster 14–16 Uhr erhöhen und Route B entlasten."
              : "Leistungsziel erreicht. Empfehlung: Ladevorgänge in die Nachtstunden verschieben (Kosten senken)."}
          </Alert>
        </Grid>
      </Grid>
    </Box>
  );
}
