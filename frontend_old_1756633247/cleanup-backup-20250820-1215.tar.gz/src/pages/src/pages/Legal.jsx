import React from "react";
export default function Legal(){return (<div className="page"><h1>Rechtliches</h1><p className="kicker">Alles auf einen Blick</p></div>);}
