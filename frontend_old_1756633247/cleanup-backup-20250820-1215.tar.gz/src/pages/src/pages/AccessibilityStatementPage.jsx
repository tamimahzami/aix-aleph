import React from "react";
export default function AccessibilityStatementPage(){return (<div className="page"><h1>Erklärung Barrierefreiheit</h1><p className="kicker">BITV / BGG</p></div>);}
