import React from "react";
export default function BusinessAreasPage(){return (<div className="page"><h1>Geschäftsbereiche</h1><p className="kicker">Unsere Felder</p></div>);}
