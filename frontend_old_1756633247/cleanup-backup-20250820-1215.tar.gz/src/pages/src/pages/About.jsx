import React from "react";
export default function About(){return (<div className="page"><h1>Über uns</h1><p className="kicker">Unternehmensprofil</p></div>);}
