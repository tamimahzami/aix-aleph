import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import "./home.css";

export default function Home() {
  useEffect(() => {
    const targets = document.querySelectorAll(".feature-card, .testimonial-card");
    const io = new IntersectionObserver((entries) =>
      entries.forEach((e) => e.isIntersecting && e.target.classList.add("animated")), { threshold: 0.1 }
    );
    targets.forEach((t) => io.observe(t));
    return () => io.disconnect();
  }, []);

  return (
    <main className="landing">
      {/* HERO */}
      <section className="hero" id="home">
        <div className="container hero-grid">
          <div className="hero-content">
            <h1><span className="brand-gradient">AI·X</span> für Industry X</h1>
            <p className="sub">
              <strong>Aleph</strong> – der Anfang: die <strong>erste intelligente, mobile Plattform</strong>,
              die KI dorthin bringt, wo Ihre Arbeit passiert. Von Flotte über Fertigung bis Energie.
            </p>
            <ul className="hero-bullets">
              <li>Vernetzt Daten, Systeme und Teams</li>
              <li>Prognostiziert, optimiert, automatisiert</li>
              <li>Sicher, skalierbar, branchenagnostisch</li>
            </ul>
            <div className="hero-buttons">
              <Link to="/register" className="btn primary">Kostenlos starten</Link>
              <a href="#why" className="btn">Mehr erfahren</a>
            </div>
          </div>

          <div className="hero-art">
            <svg viewBox="0 0 600 400" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
              <rect x="0" y="0" width="600" height="400" fill="#f0f8ff" />
              <circle cx="450" cy="150" r="80" fill="#6aa6ff" opacity="0.15" />
              <circle cx="350" cy="250" r="50" fill="#22d3ee" opacity="0.15" />
              <rect x="100" y="100" width="300" height="200" rx="20" fill="#ffffff" stroke="#6aa6ff" strokeWidth="2" />
              <circle cx="180" cy="180" r="40" fill="#22d3ee" opacity="0.25" />
              <path d="M220 150 L300 150 L300 230 L220 230 Z" fill="#2563eb" opacity="0.7" />
              <path d="M150 150 L190 150 L190 230 L150 230 Z" fill="#1e40af" opacity="0.7" />
              <circle cx="250" cy="250" r="20" fill="#22d3ee" />
            </svg>
          </div>
        </div>
      </section>

      {/* WHY (Name & Ursprung) */}
      <section id="why" className="about">
        <div className="container about-grid">
          <div className="about-text">
            <h2>Warum „AIX ALEPH“?</h2>
            <p>
              <strong>AI·X</strong> steht für <em>Künstliche Intelligenz für jede Branche</em> (Industry X).
              <strong> Aleph</strong> bezeichnet den ersten Buchstaben – Symbol für Anfang & Einheit.
              AIX ALEPH ist unser Versprechen: ein kluger Startpunkt für mobile, produktionsnahe KI-Anwendungen.
            </p>
            <p>
              Ergebnis: Entscheidungen in Minuten statt Wochen, niedrigere OPEX, höhere Verfügbarkeit – sicher und skalierbar.
            </p>
            <div className="note">
              <strong>Claim:</strong> AI·X for Industry X. The first intelligent mobile platform.
            </div>
            <div style={{marginTop:16}}>
              <Link to="/business-areas" className="btn">Geschäftsbereiche</Link>
              <Link to="/sustainability" className="btn" style={{marginLeft:8}}>Sustainability</Link>
            </div>
          </div>

          <div className="about-art">
            <svg viewBox="0 0 500 400" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
              <rect x="0" y="0" width="500" height="400" fill="#f8f9fa" />
              <rect x="50" y="50" width="400" height="300" rx="20" fill="#ffffff" stroke="#6aa6ff" strokeWidth="2" />
              <circle cx="150" cy="150" r="60" fill="#22d3ee" opacity="0.2" />
              <circle cx="350" cy="150" r="40" fill="#2563eb" opacity="0.2" />
              <rect x="100" y="220" width="120" height="60" rx="10" fill="#2563eb" opacity="0.7" />
              <rect x="280" y="220" width="120" height="60" rx="10" fill="#22d3ee" opacity="0.7" />
              <path d="M200 100 L300 100 L300 180 L200 180 Z" fill="#1e40af" opacity="0.7" />
              <circle cx="250" cy="280" r="20" fill="#22d3ee" />
            </svg>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="cta" id="contact">
        <div className="container">
          <h2>Starten Sie Ihre digitale Transformation</h2>
          <p>Sichern Sie sich eine kostenlose Erstberatung – und sehen Sie, wie AIX ALEPH Ihr Unternehmen voranbringt.</p>
          <Link to="/register" className="btn primary">Demo anfragen</Link>
        </div>
      </section>
    </main>
  );
}
