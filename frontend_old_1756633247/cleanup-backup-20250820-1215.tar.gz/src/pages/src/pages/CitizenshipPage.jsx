import React from "react";
export default function CitizenshipPage(){return (<div className="page"><h1>Corporate Citizenship</h1><p className="kicker">Gesellschaftliches Engagement</p></div>);}
