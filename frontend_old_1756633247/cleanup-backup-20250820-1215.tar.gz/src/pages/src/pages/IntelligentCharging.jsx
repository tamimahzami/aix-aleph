import React from "react";
export default function IntelligentCharging(){return (<div className="page"><h1>Intelligent Charging</h1><p className="kicker">Ladeoptimierung</p></div>);}
