cat > src/App.jsx <<'EOF'
import React from "react";
import { Routes, Route } from "react-router-dom";
import { I18nProvider } from "./i18n/I18nProvider";
import Header from "./components/Header";
import Footer from "./components/Footer";

// Kernseiten
import Home from "./pages/Home";
import About from "./pages/About";
import Status from "./pages/Status";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import NotFound from "./pages/NotFound";

// Funktionsseiten (Platzhalter)
import IntelligentCharging from "./pages/IntelligentCharging";
import PredictiveMaintenance from "./pages/PredictiveMaintenance";
import AdvancedRouting from "./pages/AdvancedRouting";
import IntegrationAutomation from "./pages/IntegrationAutomation";
import SustainabilityReporting from "./pages/SustainabilityReporting";

// Unternehmens-/Recht-Seiten (Platzhalter)
import BusinessAreasPage from "./pages/BusinessAreasPage";
import SustainabilityPage from "./pages/SustainabilityPage";
import CitizenshipPage from "./pages/CitizenshipPage";
import SupplyChainPage from "./pages/SupplyChainPage";
import AccessibilityStatementPage from "./pages/AccessibilityStatementPage";
import ImprintPage from "./pages/ImprintPage";
import TermsPage from "./pages/TermsPage";
import PrivacyPage from "./pages/PrivacyPage";
import AccessibilityPage from "./pages/AccessibilityPage";
import Legal from "./pages/Legal";

import "./App.css";

export default function App() {
  return (
    <I18nProvider>
      <div className="app-shell">
        <Header />
        <main>
          <Routes>
            {/* Hauptnavigation */}
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/status" element={<Status />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/dashboard" element={<Dashboard />} />
            {/* Mobilitäts-Funktionen */}
            <Route path="/intelligent-charging" element={<IntelligentCharging />} />
            <Route path="/predictive-maintenance" element={<PredictiveMaintenance />} />
            <Route path="/advanced-routing" element={<AdvancedRouting />} />
            <Route path="/integration-automation" element={<IntegrationAutomation />} />
            <Route path="/sustainability-reporting" element={<SustainabilityReporting />} />
            {/* Unternehmens-/Recht */}
            <Route path="/business-areas" element={<BusinessAreasPage />} />
            <Route path="/sustainability" element={<SustainabilityPage />} />
            <Route path="/citizenship" element={<CitizenshipPage />} />
            <Route path="/supply-chain" element={<SupplyChainPage />} />
            <Route path="/accessibility-statement" element={<AccessibilityStatementPage />} />
            <Route path="/imprint" element={<ImprintPage />} />
            <Route path="/terms" element={<TermsPage />} />
            <Route path="/privacy" element={<PrivacyPage />} />
            <Route path="/accessibility" element={<AccessibilityPage />} />
            <Route path="/legal" element={<Legal />} />
            {/* 404 */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </I18nProvider>
  );
}
EOF
