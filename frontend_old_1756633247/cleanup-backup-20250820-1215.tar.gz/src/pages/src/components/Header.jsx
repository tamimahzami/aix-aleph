import React from "react";
import { Link, NavLink } from "react-router-dom";
import Logo from "./Logo";
import "./Header.css";

export default function Header() {
  return (
    <header className="site-header">
      <div className="container header-row">
        <Link to="/" className="brand">
          <Logo size={24} />
        </Link>
        <nav className="nav">
          <NavLink to="/dashboard">Dashboard</NavLink>
          <NavLink to="/business-areas">Geschäftsbereiche</NavLink>
          <NavLink to="/sustainability">Sustainability</NavLink>
          <NavLink to="/careers">Jobs</NavLink>
          <NavLink to="/about">Über uns</NavLink>
          <NavLink to="/login" className="btn small">Login</NavLink>
          <NavLink to="/register" className="btn primary small">Kostenlos starten</NavLink>
        </nav>
      </div>
    </header>
  );
}
