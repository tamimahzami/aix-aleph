<footer className="site-footer">
  <div className="container">
    {/* ... deine Spalten/Links ... */}
    <div className="copyright">
      © {new Date().getFullYear()} AIX ALEPH — <span className="brand-gradient">AI·X</span> for Industry X. The first intelligent mobile platform.
      {" "}· <Link to="/privacy">Datenschutz</Link> · <Link to="/imprint">Impressum</Link>
    </div>
  </div>
</footer>
