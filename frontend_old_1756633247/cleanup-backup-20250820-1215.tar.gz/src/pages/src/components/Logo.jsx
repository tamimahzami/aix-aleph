import React from "react";

export default function Logo({ size = 22 }) {
  const title = "AIX ALEPH — AI·X for Industry X";
  return (
    <div aria-label={title} title={title} style={{display:"flex",alignItems:"baseline",gap:6}}>
      <span style={{
        fontWeight: 800,
        fontSize: size,
        letterSpacing: ".5px",
        background: "linear-gradient(90deg,#2563eb,#8b5cf6)",
        WebkitBackgroundClip: "text",
        backgroundClip: "text",
        color: "transparent",
        lineHeight: 1
      }}>
        AI<span style={{opacity:.9}}>·</span>X
      </span>
      <span style={{fontWeight:700,fontSize: size-2,color:"#0f172a",lineHeight:1}}>ALEPH</span>
    </div>
  );
}
