// src/pages/AdvancedRouting.jsx
import React from "react";
export default function AdvancedRouting() {
  return (
    <main style={{ padding: 24 }}>
      <h1>Advanced Routing</h1>
      <p>Routenoptimierung, ETA, multi-stop, constraints & KPIs.</p>
    </main>
  );
}
