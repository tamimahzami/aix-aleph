import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Login() {
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");

  function onSubmit(e) {
    e.preventDefault();
    // TODO: echte Auth integrieren
    nav("/dashboard");
  }

  return (
    <main style={{ padding: 24, display: "grid", placeItems: "center" }}>
      <form
        onSubmit={onSubmit}
        style={{
          width: "100%",
          maxWidth: 420,
          border: "1px solid #e5e7eb",
          borderRadius: 12,
          padding: 24,
          background: "#fff",
        }}
        aria-labelledby="login-title"
      >
        <h1 id="login-title" style={{ marginBottom: 16 }}>Login</h1>

        <label htmlFor="email" style={{ display: "block", fontWeight: 600 }}>
          E-Mail
        </label>
        <input
          id="email"
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          style={{ width: "100%", padding: 10, margin: "6px 0 14px", borderRadius: 8, border: "1px solid #d1d5db" }}
        />

        <label htmlFor="pw" style={{ display: "block", fontWeight: 600 }}>
          Passwort
        </label>
        <input
          id="pw"
          type="password"
          required
          value={pw}
          onChange={(e) => setPw(e.target.value)}
          style={{ width: "100%", padding: 10, margin: "6px 0 16px", borderRadius: 8, border: "1px solid #d1d5db" }}
        />

        <button
          type="submit"
          style={{
            width: "100%",
            padding: "12px 16px",
            borderRadius: 10,
            border: "none",
            background: "#2563eb",
            color: "#fff",
            fontWeight: 700,
            cursor: "pointer",
          }}
        >
          Anmelden
        </button>

        <div style={{ marginTop: 12, fontSize: 14 }}>
          Noch kein Konto? <Link to="/register">Jetzt registrieren</Link>
        </div>
      </form>
    </main>
  );
}
