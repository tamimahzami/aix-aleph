// src/pages/BusinessAreasPage.jsx
import React from "react";
export default function BusinessAreasPage() {
  return (
    <main style={{ padding: 24 }}>
      <h1>Geschäftsbereiche</h1>
      <p>Städtische Mobilität, Unternehmensflotten, Logistik, Energiemanagement.</p>
    </main>
  );
}
