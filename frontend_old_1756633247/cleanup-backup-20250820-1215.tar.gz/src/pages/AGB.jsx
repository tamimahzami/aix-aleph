import React from "react";

export default function AGB() {
  return (
    <div className="card">
      <h1>Allgemeine Geschäftsbedingungen (AGB)</h1>
      <p className="p-muted">Platzhalter-Inhalt. Hier kommen deine AGB rein.</p>
    </div>
  );
}
