export default function Fahrzeuge() {
  return (
    <div className="card">
      <h1>Fahrzeuge</h1>
      <p>Hier kommen später Filter, Liste & Detailansicht der Flotte hin.</p>
    </div>
  );
}
