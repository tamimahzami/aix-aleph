// src/pages/About.jsx
import React from "react";

export default function About() {
  return (
    <main style={{ padding: 24, maxWidth: 900, margin: "0 auto" }}>
      <h1>Über uns</h1>
      <p>
        <strong>AIX Aleph</strong> steht für <em>AI × Industrie X</em> und „Aleph“
        als Ursprung – die erste intelligente, mobile Plattform für vernetzte
        Mobilität und Energie.
      </p>
      <p>
        Wir verbinden KI, OT/IoT-Integration, Cloud & Security zu greifbaren
        Ergebnissen: effizientere Flotten, smartere Energie, klare KPIs.
      </p>
    </main>
  );
}
