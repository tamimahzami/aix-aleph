import React from "react";

export default function CareersPage() {
  return (
    <main style={{ padding: 24, maxWidth: 900, margin: "0 auto" }}>
      <h1>Jobs & Karriere</h1>
      <p>Gestalten Sie mit uns die Mobilität der Zukunft. Offene Stellen folgen.</p>
    </main>
  );
}
