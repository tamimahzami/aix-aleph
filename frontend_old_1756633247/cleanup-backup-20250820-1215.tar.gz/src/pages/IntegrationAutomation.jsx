// src/pages/IntegrationAutomation.jsx
import React from "react";
export default function IntegrationAutomation() {
  return (
    <main style={{ padding: 24 }}>
      <h1>Integration & Automation</h1>
      <p>APIs, Webhooks, iPaaS-Flows, ERP/IoT/Telematik-Integrationen.</p>
    </main>
  );
}
