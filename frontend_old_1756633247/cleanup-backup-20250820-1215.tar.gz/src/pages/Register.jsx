// src/pages/Register.jsx
import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";

export default function Register() {
  const nav = useNavigate();
  const [form, setForm] = useState({
    company: "",
    name: "",
    email: "",
    pw: "",
    accept: false,
  });

  function update(k, v) {
    setForm((s) => ({ ...s, [k]: v }));
  }

  function onSubmit(e) {
    e.preventDefault();
    // TODO: echte Registration integrieren
    nav("/dashboard");
  }

  return (
    <main style={{ padding: 24, display: "grid", placeItems: "center" }}>
      <form
        onSubmit={onSubmit}
        style={{
          width: "100%",
          maxWidth: 560,
          border: "1px solid #e5e7eb",
          borderRadius: 12,
          padding: 24,
          background: "#fff",
        }}
        aria-labelledby="register-title"
      >
        <h1 id="register-title" style={{ marginBottom: 16 }}>Registrieren</h1>

        <div style={{ display: "grid", gap: 12, gridTemplateColumns: "1fr 1fr" }}>
          <div style={{ gridColumn: "1 / -1" }}>
            <label htmlFor="company" style={{ display: "block", fontWeight: 600 }}>
              Unternehmen
            </label>
            <input
              id="company"
              value={form.company}
              onChange={(e) => update("company", e.target.value)}
              required
              style={{ width: "100%", padding: 10, marginTop: 6, borderRadius: 8, border: "1px solid #d1d5db" }}
            />
          </div>

          <div>
            <label htmlFor="name" style={{ display: "block", fontWeight: 600 }}>
              Ihr Name
            </label>
            <input
              id="name"
              value={form.name}
              onChange={(e) => update("name", e.target.value)}
              required
              style={{ width: "100%", padding: 10, marginTop: 6, borderRadius: 8, border: "1px solid #d1d5db" }}
            />
          </div>

          <div>
            <label htmlFor="email" style={{ display: "block", fontWeight: 600 }}>
              E-Mail
            </label>
            <input
              id="email"
              type="email"
              value={form.email}
              onChange={(e) => update("email", e.target.value)}
              required
              style={{ width: "100%", padding: 10, marginTop: 6, borderRadius: 8, border: "1px solid #d1d5db" }}
            />
          </div>

          <div style={{ gridColumn: "1 / -1" }}>
            <label htmlFor="pw" style={{ display: "block", fontWeight: 600 }}>
              Passwort
            </label>
            <input
              id="pw"
              type="password"
              value={form.pw}
              onChange={(e) => update("pw", e.target.value)}
              required
              style={{ width: "100%", padding: 10, marginTop: 6, borderRadius: 8, border: "1px solid #d1d5db" }}
            />
          </div>
        </div>

        <label style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 12 }}>
          <input
            type="checkbox"
            checked={form.accept}
            onChange={(e) => update("accept", e.target.checked)}
            required
          />
          <span style={{ fontSize: 14 }}>
            Ich akzeptiere <Link to="/terms">AGB</Link> und <Link to="/privacy">Datenschutz</Link>.
          </span>
        </label>

        <button
          type="submit"
          style={{
            width: "100%",
            padding: "12px 16px",
            borderRadius: 10,
            border: "none",
            background: "#16a34a",
            color: "#fff",
            fontWeight: 700,
            cursor: "pointer",
            marginTop: 16,
          }}
          disabled={!form.accept}
        >
          Konto erstellen
        </button>

        <div style={{ marginTop: 12, fontSize: 14 }}>
          Bereits ein Konto? <Link to="/login">Anmelden</Link>
        </div>
      </form>
    </main>
  );
}
