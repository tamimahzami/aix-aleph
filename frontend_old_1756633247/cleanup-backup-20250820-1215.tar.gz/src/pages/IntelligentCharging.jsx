// src/pages/IntelligentCharging.jsx
import React from "react";
export default function IntelligentCharging() {
  return (
    <main style={{ padding: 24 }}>
      <h1>Intelligent Charging</h1>
      <p>Intelligente Ladeplanung, Lastmanagement, Kostenoptimierung.</p>
    </main>
  );
}
