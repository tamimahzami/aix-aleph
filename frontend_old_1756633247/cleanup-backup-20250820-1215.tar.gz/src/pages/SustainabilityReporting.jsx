// src/pages/SustainabilityReporting.jsx
import React from "react";
export default function SustainabilityReporting() {
  return (
    <main style={{ padding: 24 }}>
      <h1>Sustainability Reporting</h1>
      <p>CO₂-Bilanz, Scope 1–3, Energie & Lade-Reports, Audits.</p>
    </main>
  );
}
