import React from "react";

export default function Impressum() {
  return (
    <div className="card">
      <h1>Impressum</h1>
      <p className="p-muted">Platzhalter-Inhalt. Verantwortliche Angaben etc.</p>
    </div>
  );
}
