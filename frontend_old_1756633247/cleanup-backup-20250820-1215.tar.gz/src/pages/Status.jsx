// src/pages/Status.jsx
import React from "react";

export default function Status() {
  return (
    <main style={{ padding: 24 }}>
      <h1>Status</h1>
      <ul style={{ lineHeight: 1.9 }}>
        <li>API: ✅ Online</li>
        <li>Datenpipelines: ✅ Stabil</li>
        <li>Realtime-Events: ✅ Normal</li>
        <li>Nächste Wartung: 03:00–04:00 CET (nur Dashboard Widgets)</li>
      </ul>
    </main>
  );
}
