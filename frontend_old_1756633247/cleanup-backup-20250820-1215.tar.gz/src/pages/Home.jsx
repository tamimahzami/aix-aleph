import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import "./home.css";

export default function Home() {
  // Reveal-Animation für Feature-Cards
  useEffect(() => {
    const cards = document.querySelectorAll(".feature-card");
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("revealed");
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.1 }
    );
    cards.forEach((c) => io.observe(c));
    return () => io.disconnect();
  }, []);

  return (
    <main className="landing">
      {/* HERO */}
      <section className="hero" id="home">
        {/* Overlay für perfekten Textkontrast */}
        <div className="hero-bg-overlay" aria-hidden="true" />
        <div className="container hero-grid">
          <div className="hero-content">
            <p className="kicker">AI × Industrie X — die intelligente Mobilitätsplattform</p>
            <h1>Industrie X trifft auf AI 🚀</h1>
            <p className="hero-sub">
              Ein Dashboard für alles: Ladeplanung, Routen, Sicherheit und Nachhaltigkeit –
              skaliert von Stadtwerken bis Parkhausnetz.
            </p>
            <div className="hero-actions">
              <Link to="/dashboard" className="btn cta large">Zum Dashboard</Link>
              <Link to="/dashboard-demo" className="btn outline large">Demo starten</Link>
            </div>
          </div>

          {/* Hero Visual – neutrales SVG (kein Foto) */}
          <div className="hero-art" aria-hidden="true">
            <svg viewBox="0 0 600 400" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <linearGradient id="g1" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.9" />
                  <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.9" />
                </linearGradient>
                <filter id="blur"><feGaussianBlur stdDeviation="18" /></filter>
              </defs>

              {/* weiche Blobs */}
              <g filter="url(#blur)" opacity="0.55">
                <circle cx="160" cy="120" r="90" fill="url(#g1)" />
                <circle cx="420" cy="180" r="120" fill="#2563eb" />
                <circle cx="320" cy="300" r="80" fill="#22d3ee" />
              </g>

              {/* „neural grid“ */}
              <g stroke="#2563eb" strokeOpacity="0.15">
                {Array.from({ length: 8 }).map((_, i) => (
                  <line key={"h"+i} x1="40" y1={60 + i * 36} x2="560" y2={60 + i * 36} />
                ))}
                {Array.from({ length: 12 }).map((_, i) => (
                  <line key={"v"+i} x1={60 + i * 44} y1="40" x2={60 + i * 44} y2="360" />
                ))}
              </g>

              {/* dezente Card */}
              <rect x="110" y="90" width="380" height="220" rx="18"
                    fill="#fff" opacity="0.9" stroke="#2563eb" />
              <circle cx="180" cy="180" r="50" fill="#22d3ee" opacity="0.25" />
              <rect x="240" y="150" width="120" height="70" rx="10"
                    fill="#2563eb" opacity="0.7" />
            </svg>
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section className="features" id="features">
        <div className="container">
          <div className="section-title">
            <h2>Unsere Kernkompetenzen</h2>
            <p className="muted">Alles in einer Plattform – messbar, sicher, skalierbar.</p>
          </div>

          <div className="features-grid">
            {[
              { icon: "⚡", title: "Intelligent Charging", text: "Kosten, Netzdruck und Verfügbarkeit smart ausbalancieren." },
              { icon: "🔧", title: "Predictive Maintenance", text: "Ausfälle vermeiden – datengetrieben und vorausschauend." },
              { icon: "🛣️", title: "Advanced Routing", text: "Optimierte Touren mit Live-Daten & KI." },
              { icon: "🌱", title: "Sustainability Reporting", text: "CO₂-Bilanz in Echtzeit verstehen und senken." }
            ].map((f, i) => (
              <div className="feature-card" key={i}>
                <div className="feature-icon">{f.icon}</div>
                <h3>{f.title}</h3>
                <p>{f.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="cta">
        <div className="container">
          <h2>Bereit für AI × Aleph?</h2>
          <p>Starte kostenlos oder erlebe die Demo live.</p>
          <div className="hero-actions">
            <Link to="/register" className="btn cta large">Kostenlos starten</Link>
            <Link to="/dashboard-demo" className="btn outline large">Demo ansehen</Link>
          </div>
        </div>
      </section>
    </main>
  );
}
