// src/pages/SustainabilityPage.jsx
import React from "react";
export default function SustainabilityPage() {
  return (
    <main style={{ padding: 24 }}>
      <h1>Corporate Sustainability</h1>
      <p>SDGs, Klimaziele, Kreislaufwirtschaft, Zertifizierungen.</p>
    </main>
  );
}
