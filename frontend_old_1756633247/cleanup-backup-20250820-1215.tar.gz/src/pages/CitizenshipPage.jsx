// src/pages/CitizenshipPage.jsx
import React from "react";
export default function CitizenshipPage() {
  return (
    <main style={{ padding: 24 }}>
      <h1>Corporate Citizenship</h1>
      <p>Bildung, soziale Mobilität, Umweltengagement, Projekte.</p>
    </main>
  );
}
