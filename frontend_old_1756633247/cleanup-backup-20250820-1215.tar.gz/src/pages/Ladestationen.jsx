export default function Ladestationen() {
  return (
    <div className="card">
      <h1>Ladestationen</h1>
      <p>Standorte, Verfügbarkeit, Auslastung – Platzhalter.</p>
    </div>
  );
}
