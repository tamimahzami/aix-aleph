// src/pages/ResetPassword.jsx
import React, { useState } from "react";
import { requestPasswordReset } from "../services/api";

export default function ResetPassword() {
  const [email, setEmail] = useState("");
  const [isLoading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");

  async function onSubmit(e) {
    e.preventDefault();
    setErr(""); setMsg("");
    setLoading(true);
    try {
      const res = await requestPasswordReset(email.trim());
      setMsg(res?.message || "Wenn die E-Mail existiert, wurde ein Reset-Link gesendet.");
    } catch (e) {
      setErr(e.message || "Anfrage fehlgeschlagen");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ maxWidth: 480, margin: "32px auto" }}>
      <h2>Passwort zurücksetzen</h2>
      <p>Gib deine E-Mail ein. Falls ein Konto existiert, erhältst du einen Link zum Zurücksetzen.</p>

      {msg && <p style={{ background:"#e6ffed", border:"1px solid #b7eb8f", padding:"8px 12px", borderRadius:8 }}>{msg}</p>}
      {err && <p style={{ background:"#fff1f0", border:"1px solid #ffa39e", padding:"8px 12px", borderRadius:8 }}>{err}</p>}

      <form onSubmit={onSubmit} style={{ marginTop: 16 }}>
        <label className="label">E-Mail</label>
        <input
          type="email"
          className="input"
          placeholder="name@firma.de"
          value={email}
          onChange={(e)=>setEmail(e.target.value)}
          required
        />
        <button className="btn btn-primary" disabled={isLoading || !email}>
          {isLoading ? "Sende…" : "Reset-Link anfordern"}
        </button>
      </form>

      <div style={{ marginTop: 16, fontSize: 14 }}>
        <a href="/login">Zurück zum Login</a>
      </div>
    </div>
  );
}
