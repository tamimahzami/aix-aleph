import React from "react";

export default function Datenschutz() {
  return (
    <div className="card">
      <h1>Datenschutzerklärung</h1>
      <p className="p-muted">Platzhalter-Inhalt. Hier folgt deine Datenschutzerklärung.</p>
    </div>
  );
}
