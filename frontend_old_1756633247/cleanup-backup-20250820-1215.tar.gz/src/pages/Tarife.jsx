export default function Tarife() {
  return (
    <div className="card">
      <h1>Tarife</h1>
      <p>Preispläne, Kostenübersicht, Buchung – Platzhalter.</p>
    </div>
  );
}
