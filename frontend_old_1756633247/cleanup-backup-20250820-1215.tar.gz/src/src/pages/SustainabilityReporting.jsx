import React from "react";

export default function SustainabilityReporting() {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>Sustainability Reporting</h1>
      <p>Hier erscheinen Berichte und KPIs rund um Nachhaltigkeit.</p>
    </div>
  );
}
