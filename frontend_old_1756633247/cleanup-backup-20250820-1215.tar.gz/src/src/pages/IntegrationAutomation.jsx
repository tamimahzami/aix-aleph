import React from "react";

export default function IntegrationAutomation() {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>Integration & Automation</h1>
      <p>Automatisierungen und Integrationen mit Drittsystemen kommen hierhin.</p>
    </div>
  );
}
