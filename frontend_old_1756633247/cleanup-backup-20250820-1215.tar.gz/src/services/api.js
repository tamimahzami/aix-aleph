// src/services/api.js
export async function startCharging(vehicleId, plugId) {
  console.debug("startCharging()", { vehicleId, plugId });
  return { ok: true };
}
export async function stopCharging(sessionId) {
  console.debug("stopCharging()", { sessionId });
  return { ok: true };
}
