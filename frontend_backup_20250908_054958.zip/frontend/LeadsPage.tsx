// statt <div className="table-cell" role="cell" colSpan={3}>
<div className="table-cell" role="cell" style={{ gridColumn: "span 3" }}>
