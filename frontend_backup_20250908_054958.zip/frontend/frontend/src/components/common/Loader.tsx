import React from "react";
export default function Loader() {
  return <div className="p-8 text-center text-muted animate-pulse">Lade Inhalte…</div>;
}
