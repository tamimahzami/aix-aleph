import React from "react";

export default function ProfessorsPage() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-10 space-y-4">
      <h2 className="text-2xl font-bold">Professors</h2>
      <p className="text-muted">Listing & Suche folgen. (DB-Anbindung via Prisma ist vorbereitet.)</p>
      <div className="panel p-4">Coming soon: Filter, Tags, Detailkarten.</div>
    </div>
  );
}
