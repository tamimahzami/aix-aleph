// Schlanker Re-Export: Falls irgendwo noch "DiscordStyleLanding" importiert wird,
// liefern wir einfach die neue Landing-Seite aus.
export { default } from "../pages/Landing";
