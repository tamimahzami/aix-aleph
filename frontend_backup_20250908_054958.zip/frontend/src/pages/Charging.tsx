export default function Charging(){
  return (
    <section className="aa-glass rounded-2xl p-6">
      <h2 className="text-xl font-semibold mb-2">Ladehistorie</h2>
      <p className="text-[var(--aa-muted)]">Sitzungen, Kosten, Effizienz.</p>
    </section>
  );
}
