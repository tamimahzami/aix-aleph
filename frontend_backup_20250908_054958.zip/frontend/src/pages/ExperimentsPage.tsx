export default function ExperimentsPage() {
  return (
    <section className="prose prose-invert max-w-3xl">
      <h1>Experiments</h1>
      <p>Experimente UI folgt.</p>
    </section>
  );
}
