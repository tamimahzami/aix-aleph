export default function Contact(){
  return (
    <section className="aa-glass rounded-2xl p-6">
      <h2 className="text-xl font-semibold mb-2">Kontakt</h2>
      <p className="text-[var(--aa-muted)]">Sag Hallo: hello@aix-aleph.example</p>
    </section>
  );
}
