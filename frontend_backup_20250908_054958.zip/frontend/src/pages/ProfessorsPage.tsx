export default function ProfessorsPage() {
  return <div className="p-6 text-[#B5BAC1]">Professors – coming soon…</div>;
}
