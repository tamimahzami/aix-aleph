// src/pages/Experiments.tsx
export default function Experiments() {
  return (
    <section className="prose prose-invert max-w-3xl mx-auto p-6">
      <h1>Experiments</h1>
      <p>Hier erscheinen alle Experimente.</p>
    </section>
  );
}
