export default function Settings() {
  return (
    <div className="grid">
      <h1>Settings</h1>
      <div className="card">Noch nix hier – später API Keys, Themes, etc.</div>
    </div>
  );
}
