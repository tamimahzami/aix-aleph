export default function Account(){
  return (
    <section className="aa-glass rounded-2xl p-6">
      <h2 className="text-xl font-semibold mb-2">Mein Konto</h2>
      <p className="text-[var(--aa-muted)]">Profil & Einstellungen.</p>
    </section>
  );
}
