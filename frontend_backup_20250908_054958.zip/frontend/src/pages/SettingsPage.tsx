export default function SettingsPage() {
  return (
    <section className="prose prose-invert max-w-3xl">
      <h1>Einstellungen</h1>
      <p>Benutzer & App-Einstellungen.</p>
    </section>
  );
}
