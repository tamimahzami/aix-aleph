export default function Acknowledgements() {
  return (
    <>
      <h1>Danksagungen</h1>
      <p>Hier stehen die Danksagungen für AIX Aleph.</p>
    </>
  );
}
