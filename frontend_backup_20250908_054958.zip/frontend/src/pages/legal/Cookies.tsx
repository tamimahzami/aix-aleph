export default function Cookies() {
  return (
    <>
      <h1>Cookie-Richtlinien</h1>
      <p>Hier stehen die Cookie-Richtlinien von AIX Aleph.</p>
    </>
  );
}
