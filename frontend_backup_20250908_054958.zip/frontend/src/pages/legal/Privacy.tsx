export default function Privacy() {
  return (
    <>
      <h1>Datenschutzerklärung</h1>
      <p>Hier steht die Datenschutzerklärung von AIX Aleph.</p>
    </>
  );
}
