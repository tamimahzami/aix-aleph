export default function Company() {
  return (
    <>
      <h1>Unternehmensinformationen</h1>
      <p>Hier stehen die Unternehmensinformationen von AIX Aleph.</p>
    </>
  );
}
