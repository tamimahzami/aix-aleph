export default function Guidelines() {
  return (
    <>
      <h1>Richtlinien</h1>
      <p>Hier stehen die Nutzungsrichtlinien von AIX Aleph.</p>
    </>
  );
}
