export default function Terms() {
  return (
    <>
      <h1>Allgemeine Geschäftsbedingungen</h1>
      <p>Hier stehen die AGB von AIX Aleph.</p>
    </>
  );
}
