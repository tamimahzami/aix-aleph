export default function Licenses() {
  return (
    <>
      <h1>Lizenzen</h1>
      <p>Hier stehen die Lizenzinformationen von AIX Aleph.</p>
    </>
  );
}
