export default function Unternehmen() {
  return (
    <div className="card">
      <h1>Für Unternehmen</h1>
      <p>Use-Cases, Integrationen, Sicherheit – Platzhalter.</p>
    </div>
  );
}
