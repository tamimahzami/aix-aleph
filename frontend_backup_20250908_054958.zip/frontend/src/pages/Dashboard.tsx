// src/pages/Dashboard.tsx
export default function Dashboard() {
  return (
    <section className="prose prose-invert max-w-3xl mx-auto p-6">
      <h1>Dashboard</h1>
      <p>Willkommen im AIX ALEPH Dashboard 🚀</p>
    </section>
  );
}
